package com.amos.service;

public interface IHello {
	
	public String sayHi();
	
}
